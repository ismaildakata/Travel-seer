import { Mail, Globe, MapPin, Heart } from "lucide-react";

export default function About() {
  return (
    <div className="max-w-2xl mx-auto space-y-10">
      <div>
        <h1 className="font-serif text-3xl font-bold text-foreground mb-1">About Travel Seer</h1>
        <p className="text-muted-foreground">The team and vision behind the app.</p>
      </div>

      {/* App description */}
      <div className="bg-gradient-to-br from-primary/90 to-secondary rounded-2xl p-8 text-primary-foreground">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
            <Globe size={22} className="text-white" />
          </div>
          <h2 className="font-serif text-2xl font-bold">Travel Seer</h2>
        </div>
        <p className="text-primary-foreground/90 leading-relaxed text-base">
          Travel Seer is a comprehensive travel planning and discovery platform that helps adventurers
          browse destinations from every corner of the globe, plan their trips, track their journeys,
          and save places they dream of visiting. Built with a passion for exploration and discovery.
        </p>
        <div className="mt-5 flex flex-wrap gap-3">
          {["Destination Discovery", "Trip Planning", "Journey Tracking", "Travel Stats"].map((tag) => (
            <span key={tag} className="bg-white/20 text-white text-xs font-medium px-3 py-1 rounded-full">
              {tag}
            </span>
          ))}
        </div>
      </div>

      {/* Owner card */}
      <div className="bg-card border border-border rounded-2xl p-8">
        <h2 className="font-serif text-xl font-semibold text-foreground mb-6">Meet the Developer</h2>
        <div className="flex flex-col sm:flex-row gap-6 items-start">
          {/* Profile picture */}
          <div className="shrink-0">
            <div className="w-28 h-28 rounded-2xl overflow-hidden bg-primary/10 border-2 border-primary/20 flex items-center justify-center">
              <img
                src={`${import.meta.env.BASE_URL}owner-photo.jpg`}
                alt="Ismail Ado Dakata"
                className="w-full h-full object-cover"
                onError={(e) => {
                  const target = e.currentTarget;
                  target.style.display = "none";
                  target.parentElement!.innerHTML = `<span class="font-serif text-3xl font-bold text-primary">ID</span>`;
                }}
              />
            </div>
          </div>

          {/* Info */}
          <div className="flex-1 space-y-3">
            <div>
              <h3 className="font-serif text-2xl font-bold text-foreground">Ismail Ado Dakata</h3>
              <p className="text-muted-foreground text-sm mt-0.5">Founder &amp; Developer</p>
            </div>

            <p className="text-foreground/80 leading-relaxed text-sm">
              Passionate about travel, technology, and building tools that connect people with the world.
              Travel Seer was born from a desire to make trip planning more intuitive, organised,
              and inspiring for every adventurer.
            </p>

            <div className="flex flex-col gap-2 pt-1">
              <a
                href="mailto:ismailadodakata@gmail.com"
                className="flex items-center gap-2 text-primary hover:underline text-sm"
              >
                <Mail size={15} /> ismailadodakata@gmail.com
              </a>
              <span className="flex items-center gap-2 text-muted-foreground text-sm">
                <MapPin size={15} /> Nigeria
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Mission */}
      <div className="bg-card border border-border rounded-2xl p-8 space-y-4">
        <div className="flex items-center gap-2">
          <Heart size={18} className="text-primary" />
          <h2 className="font-serif text-xl font-semibold text-foreground">Our Mission</h2>
        </div>
        <p className="text-foreground/80 leading-relaxed">
          We believe every journey starts with a dream. Travel Seer exists to turn those dreams into
          well-organised, memorable adventures. From the bustling streets of Tokyo to the pristine
          beaches of the Maldives — we help you discover, plan, and cherish every mile.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          {[
            { icon: "🌍", label: "Global Coverage", desc: "Destinations across all 6 continents" },
            { icon: "🗓️", label: "Smart Planning", desc: "Organise trips from start to finish" },
            { icon: "📍", label: "Save & Discover", desc: "Bookmark places you love" },
          ].map((item) => (
            <div key={item.label} className="bg-accent/50 rounded-xl p-4 text-center">
              <div className="text-2xl mb-2">{item.icon}</div>
              <p className="font-semibold text-foreground text-sm">{item.label}</p>
              <p className="text-muted-foreground text-xs mt-1">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Contact */}
      <div className="text-center py-6 text-muted-foreground text-sm">
        <p>Have a question or suggestion?</p>
        <a href="mailto:ismailadodakata@gmail.com" className="text-primary font-medium hover:underline mt-1 block">
          Get in touch →
        </a>
      </div>
    </div>
  );
}
