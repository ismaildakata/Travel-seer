import { useGetFeaturedDestinations, useGetTravelStats, useListTrips, useSaveDestination, useUnsaveDestination, useListSavedDestinations, getGetFeaturedDestinationsQueryKey, getGetTravelStatsQueryKey, getListSavedDestinationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { MapPin, Globe, CheckCircle, Bookmark, BookmarkCheck, TrendingUp, Calendar, ArrowRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const DEMO_USER_ID = 1;

export default function Home() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: featured, isLoading: featuredLoading } = useGetFeaturedDestinations();
  const { data: stats, isLoading: statsLoading } = useGetTravelStats({ query: { queryKey: getGetTravelStatsQueryKey({ userId: DEMO_USER_ID }) } });
  const { data: recentTrips, isLoading: tripsLoading } = useListTrips({ query: { queryKey: [] } });
  const { data: saved } = useListSavedDestinations(
    { userId: DEMO_USER_ID },
    { query: { queryKey: getListSavedDestinationsQueryKey({ userId: DEMO_USER_ID }) } }
  );

  const saveDestination = useSaveDestination();
  const unsaveDestination = useUnsaveDestination();

  const savedDestinationIds = new Set(saved?.map((s) => s.destinationId) ?? []);
  const savedMap = new Map(saved?.map((s) => [s.destinationId, s.id]) ?? []);

  const handleSaveToggle = (destinationId: number) => {
    if (savedDestinationIds.has(destinationId)) {
      const savedId = savedMap.get(destinationId)!;
      unsaveDestination.mutate({ id: savedId }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSavedDestinationsQueryKey({ userId: DEMO_USER_ID }) });
          toast({ title: "Removed from saved" });
        }
      });
    } else {
      saveDestination.mutate({ data: { userId: DEMO_USER_ID, destinationId } }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSavedDestinationsQueryKey({ userId: DEMO_USER_ID }) });
          queryClient.invalidateQueries({ queryKey: getGetTravelStatsQueryKey({ userId: DEMO_USER_ID }) });
          toast({ title: "Destination saved!" });
        }
      });
    }
  };

  const statCards = [
    { label: "Destinations", value: stats?.totalDestinations ?? 0, icon: Globe, loading: statsLoading },
    { label: "Trips Planned", value: stats?.totalTrips ?? 0, icon: Calendar, loading: statsLoading },
    { label: "Completed", value: stats?.completedTrips ?? 0, icon: CheckCircle, loading: statsLoading },
    { label: "Countries", value: stats?.totalCountriesVisited ?? 0, icon: TrendingUp, loading: statsLoading },
  ];

  const userTrips = recentTrips?.filter((t) => t.userId === DEMO_USER_ID).slice(0, 3) ?? [];

  return (
    <div className="space-y-10">
      {/* Hero */}
      <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-primary/90 to-secondary px-8 py-12 text-primary-foreground">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_30%_107%,_#fda085_0%,_#f6d365_30%,_transparent_60%)]" />
        <div className="relative z-10">
          <p className="text-primary-foreground/70 text-sm font-medium tracking-widest uppercase mb-2">Your Journey Awaits</p>
          <h1 className="font-serif text-4xl md:text-5xl font-bold mb-3 leading-tight">Where will you go<br />next?</h1>
          <p className="text-primary-foreground/80 max-w-md text-base mb-6">Track your adventures, discover new destinations, and plan your next journey.</p>
          <Link href="/trips/new">
            <Button variant="secondary" className="gap-2 font-semibold" data-testid="button-plan-trip">
              Plan a Trip <ArrowRight size={16} />
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {statCards.map((s) => (
          <div key={s.label} className="bg-card border border-border rounded-xl p-5 flex flex-col gap-2" data-testid={`card-stat-${s.label.toLowerCase()}`}>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground text-sm font-medium">{s.label}</span>
              <s.icon size={18} className="text-primary" />
            </div>
            {s.loading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <span className="font-serif text-3xl font-bold text-foreground">{s.value}</span>
            )}
          </div>
        ))}
      </div>

      {/* Featured Destinations */}
      <section>
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-serif text-2xl font-bold text-foreground">Featured Destinations</h2>
          <Link href="/destinations" className="text-primary text-sm font-medium hover:underline flex items-center gap-1">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {featuredLoading
            ? Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="rounded-xl overflow-hidden border border-border">
                  <Skeleton className="h-44 w-full" />
                  <div className="p-4 space-y-2">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
              ))
            : (featured ?? []).map((dest) => (
                <Link key={dest.id} href={`/destinations/${dest.id}`}>
                  <div className="group rounded-xl overflow-hidden border border-border bg-card hover:shadow-lg transition-all duration-200 cursor-pointer" data-testid={`card-destination-${dest.id}`}>
                    <div className="relative h-44 overflow-hidden">
                      {dest.imageUrl ? (
                        <img
                          src={dest.imageUrl}
                          alt={dest.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center">
                          <MapPin className="text-muted-foreground" size={32} />
                        </div>
                      )}
                      <button
                        onClick={(e) => { e.preventDefault(); handleSaveToggle(dest.id); }}
                        className="absolute top-3 right-3 bg-white/80 backdrop-blur-sm rounded-full p-1.5 shadow hover:bg-white transition-colors"
                        data-testid={`button-save-${dest.id}`}
                      >
                        {savedDestinationIds.has(dest.id)
                          ? <BookmarkCheck size={16} className="text-primary" />
                          : <Bookmark size={16} className="text-foreground/60" />}
                      </button>
                    </div>
                    <div className="p-4">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-semibold text-foreground text-base">{dest.name}</h3>
                          <p className="text-muted-foreground text-sm flex items-center gap-1 mt-0.5">
                            <MapPin size={12} /> {dest.country}
                          </p>
                        </div>
                        <Badge variant="outline" className="text-xs shrink-0">${dest.avgCostPerDay}/day</Badge>
                      </div>
                      <p className="text-muted-foreground text-xs mt-2 line-clamp-2">{dest.description}</p>
                    </div>
                  </div>
                </Link>
              ))}
        </div>
      </section>

      {/* Recent Trips */}
      {(tripsLoading || userTrips.length > 0) && (
        <section>
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-serif text-2xl font-bold text-foreground">Recent Trips</h2>
            <Link href="/trips" className="text-primary text-sm font-medium hover:underline flex items-center gap-1">
              All trips <ArrowRight size={14} />
            </Link>
          </div>
          <div className="space-y-3">
            {tripsLoading
              ? Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-20 w-full rounded-xl" />)
              : userTrips.map((trip) => (
                  <div key={trip.id} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4" data-testid={`card-trip-${trip.id}`}>
                    {trip.destination?.imageUrl && (
                      <img src={trip.destination.imageUrl} alt={trip.destination.name} className="w-14 h-14 rounded-lg object-cover shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-foreground truncate">{trip.destination?.name ?? "Unknown"}</p>
                        <Badge
                          variant={trip.status === "completed" ? "default" : trip.status === "ongoing" ? "secondary" : "outline"}
                          className="text-xs"
                        >
                          {trip.status}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground text-sm">{trip.startDate} — {trip.endDate}</p>
                    </div>
                    {trip.budget && (
                      <span className="text-sm font-medium text-foreground shrink-0">${trip.budget.toLocaleString()}</span>
                    )}
                  </div>
                ))}
          </div>
        </section>
      )}
    </div>
  );
}
