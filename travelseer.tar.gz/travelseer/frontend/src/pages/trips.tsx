import { useListTrips, useDeleteTrip, getListTripsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { MapPin, Calendar, Trash2, Plus, Plane } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const DEMO_USER_ID = 1;

type TripStatus = "all" | "planned" | "ongoing" | "completed";

const STATUS_COLORS: Record<string, string> = {
  planned: "outline",
  ongoing: "secondary",
  completed: "default",
};

export default function Trips() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<TripStatus>("all");

  const params = {
    userId: DEMO_USER_ID,
    ...(filter !== "all" ? { status: filter as "planned" | "ongoing" | "completed" } : {}),
  };

  const { data: trips, isLoading } = useListTrips(params, {
    query: { queryKey: getListTripsQueryKey(params) }
  });

  const deleteTrip = useDeleteTrip();

  const handleDelete = (id: number) => {
    deleteTrip.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTripsQueryKey({ userId: DEMO_USER_ID }) });
        toast({ title: "Trip deleted" });
      }
    });
  };

  const tabs: { label: string; value: TripStatus }[] = [
    { label: "All", value: "all" },
    { label: "Planned", value: "planned" },
    { label: "Ongoing", value: "ongoing" },
    { label: "Completed", value: "completed" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-serif text-3xl font-bold text-foreground mb-1">My Trips</h1>
          <p className="text-muted-foreground">Track your adventures past, present, and future.</p>
        </div>
        <Link href="/trips/new">
          <Button className="gap-2 font-semibold" data-testid="button-new-trip">
            <Plus size={16} /> Plan Trip
          </Button>
        </Link>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap">
        {tabs.map((tab) => (
          <button
            key={tab.value}
            onClick={() => setFilter(tab.value)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
              filter === tab.value
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
            data-testid={`tab-${tab.value}`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Trip list */}
      <div className="space-y-4">
        {isLoading
          ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-28 w-full rounded-xl" />)
          : (trips ?? []).map((trip) => (
              <div key={trip.id} className="bg-card border border-border rounded-xl p-5 flex gap-4 items-start" data-testid={`card-trip-${trip.id}`}>
                <div className="shrink-0">
                  {trip.destination?.imageUrl ? (
                    <img
                      src={trip.destination.imageUrl}
                      alt={trip.destination.name}
                      className="w-20 h-20 rounded-lg object-cover"
                    />
                  ) : (
                    <div className="w-20 h-20 rounded-lg bg-muted flex items-center justify-center">
                      <Plane size={24} className="text-muted-foreground" />
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div>
                      <h3 className="font-semibold text-foreground text-base">{trip.destination?.name ?? "Unknown destination"}</h3>
                      <p className="text-muted-foreground text-sm flex items-center gap-1">
                        <MapPin size={12} /> {trip.destination?.country}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Badge variant={STATUS_COLORS[trip.status] as "default" | "secondary" | "outline"} className="text-xs">
                        {trip.status}
                      </Badge>
                      <button
                        onClick={() => handleDelete(trip.id)}
                        className="text-muted-foreground hover:text-destructive transition-colors"
                        data-testid={`button-delete-trip-${trip.id}`}
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1"><Calendar size={13} /> {trip.startDate} — {trip.endDate}</span>
                    {trip.budget && <span className="font-medium text-foreground">${trip.budget.toLocaleString()} budget</span>}
                  </div>
                  {trip.notes && (
                    <p className="text-sm text-muted-foreground mt-2 italic line-clamp-1">"{trip.notes}"</p>
                  )}
                </div>
              </div>
            ))}
      </div>

      {!isLoading && trips?.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <Plane size={40} className="mx-auto mb-3 opacity-30" />
          <p className="font-medium">No trips yet</p>
          <p className="text-sm mt-1">Start planning your next adventure</p>
          <Link href="/trips/new">
            <Button className="mt-4 gap-2" data-testid="button-plan-first-trip">
              <Plus size={16} /> Plan your first trip
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
