import { useState } from "react";
import { useListDestinations, useSaveDestination, useUnsaveDestination, useListSavedDestinations, getListSavedDestinationsQueryKey, getListDestinationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { MapPin, Bookmark, BookmarkCheck, Search, SlidersHorizontal } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const DEMO_USER_ID = 1;
const CONTINENTS = ["Africa", "Asia", "Europe", "North America", "South America", "Oceania"];

export default function Destinations() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [continent, setContinent] = useState("all");

  const params = {
    ...(search ? { search } : {}),
    ...(continent !== "all" ? { continent } : {}),
  };

  const { data: destinations, isLoading } = useListDestinations(params, {
    query: { queryKey: getListDestinationsQueryKey(params) }
  });

  const { data: saved } = useListSavedDestinations(
    { userId: DEMO_USER_ID },
    { query: { queryKey: getListSavedDestinationsQueryKey({ userId: DEMO_USER_ID }) } }
  );

  const saveDestination = useSaveDestination();
  const unsaveDestination = useUnsaveDestination();

  const savedDestinationIds = new Set(saved?.map((s) => s.destinationId) ?? []);
  const savedMap = new Map(saved?.map((s) => [s.destinationId, s.id]) ?? []);

  const handleSaveToggle = (e: React.MouseEvent, destinationId: number) => {
    e.preventDefault();
    if (savedDestinationIds.has(destinationId)) {
      const savedId = savedMap.get(destinationId)!;
      unsaveDestination.mutate({ id: savedId }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSavedDestinationsQueryKey({ userId: DEMO_USER_ID }) });
          toast({ title: "Removed from saved" });
        }
      });
    } else {
      saveDestination.mutate({ data: { userId: DEMO_USER_ID, destinationId } }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSavedDestinationsQueryKey({ userId: DEMO_USER_ID }) });
          toast({ title: "Destination saved!" });
        }
      });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-serif text-3xl font-bold text-foreground mb-1">Destinations</h1>
        <p className="text-muted-foreground">Discover your next adventure from around the world.</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            data-testid="input-search"
            placeholder="Search destinations..."
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <SlidersHorizontal size={16} className="text-muted-foreground" />
          <Select value={continent} onValueChange={setContinent}>
            <SelectTrigger className="w-44" data-testid="select-continent">
              <SelectValue placeholder="All continents" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All continents</SelectItem>
              {CONTINENTS.map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Results count */}
      {!isLoading && (
        <p className="text-sm text-muted-foreground">{destinations?.length ?? 0} destination{destinations?.length !== 1 ? "s" : ""} found</p>
      )}

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {isLoading
          ? Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="rounded-xl overflow-hidden border border-border">
                <Skeleton className="h-48 w-full" />
                <div className="p-4 space-y-2">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-full" />
                </div>
              </div>
            ))
          : (destinations ?? []).map((dest) => (
              <Link key={dest.id} href={`/destinations/${dest.id}`}>
                <div className="group rounded-xl overflow-hidden border border-border bg-card hover:shadow-lg transition-all duration-200 cursor-pointer h-full" data-testid={`card-destination-${dest.id}`}>
                  <div className="relative h-48 overflow-hidden">
                    {dest.imageUrl ? (
                      <img
                        src={dest.imageUrl}
                        alt={dest.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          const img = e.currentTarget;
                          img.style.display = "none";
                          const fallback = img.nextElementSibling as HTMLElement | null;
                          if (fallback) fallback.style.display = "flex";
                        }}
                      />
                    ) : null}
                    <div
                      className="w-full h-full bg-muted flex-col items-center justify-center gap-2"
                      style={{ display: dest.imageUrl ? "none" : "flex" }}
                    >
                      <MapPin className="text-muted-foreground" size={32} />
                      <span className="text-xs text-muted-foreground font-medium">{dest.name}</span>
                    </div>
                    {dest.isFeatured && (
                      <span className="absolute top-3 left-3 bg-primary text-primary-foreground text-xs font-medium px-2 py-1 rounded-full">
                        Featured
                      </span>
                    )}
                    <button
                      onClick={(e) => handleSaveToggle(e, dest.id)}
                      className="absolute top-3 right-3 bg-white/80 backdrop-blur-sm rounded-full p-1.5 shadow hover:bg-white transition-colors"
                      data-testid={`button-save-${dest.id}`}
                    >
                      {savedDestinationIds.has(dest.id)
                        ? <BookmarkCheck size={16} className="text-primary" />
                        : <Bookmark size={16} className="text-foreground/60" />}
                    </button>
                  </div>
                  <div className="p-4 flex flex-col gap-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="font-semibold text-foreground">{dest.name}</h3>
                        <p className="text-muted-foreground text-sm flex items-center gap-1">
                          <MapPin size={12} /> {dest.country}, {dest.continent}
                        </p>
                      </div>
                      <Badge variant="outline" className="text-xs shrink-0">${dest.avgCostPerDay}/day</Badge>
                    </div>
                    <p className="text-muted-foreground text-sm line-clamp-2">{dest.description}</p>
                    <p className="text-xs text-muted-foreground mt-1">Best: {dest.bestSeason}</p>
                  </div>
                </div>
              </Link>
            ))}
      </div>

      {!isLoading && destinations?.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <MapPin size={40} className="mx-auto mb-3 opacity-30" />
          <p className="font-medium">No destinations found</p>
          <p className="text-sm mt-1">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}
