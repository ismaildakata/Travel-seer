import { useGetDestination, useSaveDestination, useUnsaveDestination, useListSavedDestinations, getListSavedDestinationsQueryKey, getGetDestinationQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { MapPin, Calendar, DollarSign, Sun, Bookmark, BookmarkCheck, ArrowLeft, Plus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

const DEMO_USER_ID = 1;

export default function DestinationDetail() {
  const { id } = useParams<{ id: string }>();
  const destId = Number(id);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: dest, isLoading } = useGetDestination(destId, {
    query: { enabled: !!destId, queryKey: getGetDestinationQueryKey(destId) }
  });

  const { data: saved } = useListSavedDestinations(
    { userId: DEMO_USER_ID },
    { query: { queryKey: getListSavedDestinationsQueryKey({ userId: DEMO_USER_ID }) } }
  );

  const saveDestination = useSaveDestination();
  const unsaveDestination = useUnsaveDestination();

  const savedEntry = saved?.find((s) => s.destinationId === destId);
  const isSaved = !!savedEntry;

  const handleSaveToggle = () => {
    if (isSaved && savedEntry) {
      unsaveDestination.mutate({ id: savedEntry.id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSavedDestinationsQueryKey({ userId: DEMO_USER_ID }) });
          toast({ title: "Removed from saved" });
        }
      });
    } else {
      saveDestination.mutate({ data: { userId: DEMO_USER_ID, destinationId: destId } }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSavedDestinationsQueryKey({ userId: DEMO_USER_ID }) });
          toast({ title: "Destination saved!" });
        }
      });
    }
  };

  return (
    <div className="space-y-8 max-w-3xl mx-auto">
      <Link href="/destinations" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-sm" data-testid="link-back">
        <ArrowLeft size={16} /> Back to destinations
      </Link>

      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-72 w-full rounded-2xl" />
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-20 w-full" />
        </div>
      ) : dest ? (
        <>
          {/* Hero image */}
          <div className="relative h-72 md:h-96 rounded-2xl overflow-hidden">
            {dest.imageUrl ? (
              <img src={dest.imageUrl} alt={dest.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-muted flex items-center justify-center">
                <MapPin size={48} className="text-muted-foreground" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="absolute bottom-5 left-6 right-6 flex items-end justify-between">
              <div>
                <h1 className="font-serif text-3xl md:text-4xl font-bold text-white mb-1">{dest.name}</h1>
                <p className="text-white/80 flex items-center gap-1.5">
                  <MapPin size={14} /> {dest.country}, {dest.continent}
                </p>
              </div>
              {dest.isFeatured && (
                <Badge className="bg-primary text-primary-foreground">Featured</Badge>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex gap-3">
            <Link href={`/trips/new?destinationId=${dest.id}`} className="flex-1">
              <Button className="w-full gap-2 font-semibold" data-testid="button-plan-trip">
                <Plus size={16} /> Plan a Trip Here
              </Button>
            </Link>
            <Button
              variant="outline"
              className="gap-2"
              onClick={handleSaveToggle}
              data-testid="button-save-destination"
            >
              {isSaved ? <BookmarkCheck size={16} className="text-primary" /> : <Bookmark size={16} />}
              {isSaved ? "Saved" : "Save"}
            </Button>
          </div>

          {/* Info cards */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-card border border-border rounded-xl p-4 text-center" data-testid="card-cost">
              <DollarSign size={20} className="text-primary mx-auto mb-1" />
              <p className="font-bold text-foreground text-lg">${dest.avgCostPerDay}</p>
              <p className="text-muted-foreground text-xs">per day avg</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 text-center" data-testid="card-season">
              <Sun size={20} className="text-primary mx-auto mb-1" />
              <p className="font-medium text-foreground text-sm leading-tight">{dest.bestSeason}</p>
              <p className="text-muted-foreground text-xs mt-1">best season</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 text-center" data-testid="card-continent">
              <Calendar size={20} className="text-primary mx-auto mb-1" />
              <p className="font-medium text-foreground text-sm">{dest.continent}</p>
              <p className="text-muted-foreground text-xs mt-1">continent</p>
            </div>
          </div>

          {/* Description */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="font-serif text-xl font-bold mb-3 text-foreground">About {dest.name}</h2>
            <p className="text-foreground/80 leading-relaxed">{dest.description}</p>
          </div>
        </>
      ) : (
        <div className="text-center py-20 text-muted-foreground">
          <MapPin size={40} className="mx-auto mb-3 opacity-30" />
          <p className="font-medium">Destination not found</p>
          <Link href="/destinations" className="text-primary text-sm mt-2 block hover:underline">Browse destinations</Link>
        </div>
      )}
    </div>
  );
}
