import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useListDestinations, useCreateTrip, getListTripsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation, useSearch } from "wouter";
import { ArrowLeft, Plane } from "lucide-react";
import { Link } from "wouter";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const DEMO_USER_ID = 1;

const schema = z.object({
  destinationId: z.string().min(1, "Please select a destination"),
  status: z.enum(["planned", "ongoing", "completed"]),
  startDate: z.string().min(1, "Start date required"),
  endDate: z.string().min(1, "End date required"),
  budget: z.string().optional(),
  notes: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export default function NewTrip() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const preselectedDestId = params.get("destinationId");

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: destinations } = useListDestinations();
  const createTrip = useCreateTrip();

  const form = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      destinationId: preselectedDestId ?? "",
      status: "planned",
      startDate: "",
      endDate: "",
      budget: "",
      notes: "",
    },
  });

  const onSubmit = (values: FormData) => {
    createTrip.mutate(
      {
        data: {
          userId: DEMO_USER_ID,
          destinationId: Number(values.destinationId),
          status: values.status,
          startDate: values.startDate,
          endDate: values.endDate,
          budget: values.budget ? Number(values.budget) : undefined,
          notes: values.notes || undefined,
        },
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListTripsQueryKey({ userId: DEMO_USER_ID }) });
          toast({ title: "Trip planned!", description: "Your adventure is on the books." });
          setLocation("/trips");
        },
        onError: () => {
          toast({ title: "Something went wrong", description: "Could not save your trip.", variant: "destructive" });
        },
      }
    );
  };

  return (
    <div className="max-w-xl mx-auto space-y-8">
      <Link href="/trips" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-sm" data-testid="link-back">
        <ArrowLeft size={16} /> Back to trips
      </Link>

      <div>
        <div className="flex items-center gap-3 mb-1">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Plane size={20} className="text-primary" />
          </div>
          <h1 className="font-serif text-3xl font-bold text-foreground">Plan a Trip</h1>
        </div>
        <p className="text-muted-foreground mt-1">Fill in the details and get ready to explore.</p>
      </div>

      <div className="bg-card border border-border rounded-2xl p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <FormField
              control={form.control}
              name="destinationId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Destination</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-destination">
                        <SelectValue placeholder="Choose a destination" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {(destinations ?? []).map((d) => (
                        <SelectItem key={d.id} value={String(d.id)}>
                          {d.name}, {d.country}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Trip Status</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-status">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="planned">Planned</SelectItem>
                      <SelectItem value="ongoing">Ongoing</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} data-testid="input-start-date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} data-testid="input-end-date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="budget"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Budget (USD, optional)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      placeholder="e.g. 2000"
                      {...field}
                      data-testid="input-budget"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="What do you want to do or see?"
                      rows={3}
                      {...field}
                      data-testid="textarea-notes"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full font-semibold gap-2"
              disabled={createTrip.isPending}
              data-testid="button-submit-trip"
            >
              <Plane size={16} />
              {createTrip.isPending ? "Saving..." : "Plan This Trip"}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
