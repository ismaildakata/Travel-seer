import { useGetUser, useUpdateUser, useListSavedDestinations, useUnsaveDestination, getGetUserQueryKey, getListSavedDestinationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "wouter";
import { MapPin, User as UserIcon, Bookmark, Globe, X } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";

const DEMO_USER_ID = 1;

const schema = z.object({
  name: z.string().min(1, "Name is required"),
  bio: z.string().optional(),
  homeCountry: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export default function Profile() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: user, isLoading: userLoading } = useGetUser(DEMO_USER_ID, {
    query: { queryKey: getGetUserQueryKey(DEMO_USER_ID) }
  });

  const { data: saved, isLoading: savedLoading } = useListSavedDestinations(
    { userId: DEMO_USER_ID },
    { query: { queryKey: getListSavedDestinationsQueryKey({ userId: DEMO_USER_ID }) } }
  );

  const updateUser = useUpdateUser();
  const unsaveDestination = useUnsaveDestination();

  const form = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", bio: "", homeCountry: "" },
  });

  useEffect(() => {
    if (user) {
      form.reset({
        name: user.name,
        bio: user.bio ?? "",
        homeCountry: user.homeCountry ?? "",
      });
    }
  }, [user, form]);

  const onSubmit = (values: FormData) => {
    updateUser.mutate(
      { id: DEMO_USER_ID, data: { name: values.name, bio: values.bio || undefined, homeCountry: values.homeCountry || undefined } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetUserQueryKey(DEMO_USER_ID) });
          toast({ title: "Profile updated!" });
        },
        onError: () => {
          toast({ title: "Failed to update profile", variant: "destructive" });
        },
      }
    );
  };

  const handleUnsave = (savedId: number) => {
    unsaveDestination.mutate({ id: savedId }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSavedDestinationsQueryKey({ userId: DEMO_USER_ID }) });
        toast({ title: "Removed from saved" });
      }
    });
  };

  return (
    <div className="space-y-8 max-w-2xl">
      <div>
        <h1 className="font-serif text-3xl font-bold text-foreground mb-1">Profile</h1>
        <p className="text-muted-foreground">Your traveler identity and saved places.</p>
      </div>

      {/* Avatar + Info Header */}
      {userLoading ? (
        <div className="flex items-center gap-4">
          <Skeleton className="w-16 h-16 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-4 w-48" />
          </div>
        </div>
      ) : user ? (
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
            <UserIcon size={28} className="text-primary" />
          </div>
          <div>
            <h2 className="font-serif text-xl font-bold text-foreground">{user.name}</h2>
            <p className="text-muted-foreground text-sm">{user.email}</p>
            {user.homeCountry && (
              <p className="text-muted-foreground text-sm flex items-center gap-1 mt-0.5">
                <Globe size={12} /> {user.homeCountry}
              </p>
            )}
          </div>
        </div>
      ) : null}

      {/* Edit form */}
      <div className="bg-card border border-border rounded-2xl p-6 space-y-5">
        <h3 className="font-semibold text-foreground">Edit Profile</h3>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Your name" {...field} data-testid="input-name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="homeCountry"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Home Country</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. United States" {...field} data-testid="input-home-country" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="bio"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bio</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Tell the world about your travel style..." rows={3} {...field} data-testid="textarea-bio" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="font-semibold" disabled={updateUser.isPending} data-testid="button-save-profile">
              {updateUser.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </form>
        </Form>
      </div>

      {/* Saved destinations */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Bookmark size={18} className="text-primary" />
          <h3 className="font-semibold text-foreground">Saved Destinations</h3>
          <Badge variant="outline" className="text-xs">{saved?.length ?? 0}</Badge>
        </div>
        {savedLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}
          </div>
        ) : (saved ?? []).length === 0 ? (
          <div className="text-center py-8 text-muted-foreground border border-dashed border-border rounded-xl">
            <MapPin size={28} className="mx-auto mb-2 opacity-30" />
            <p className="text-sm">No saved destinations yet</p>
            <Link href="/destinations" className="text-primary text-sm mt-1 block hover:underline">Browse destinations</Link>
          </div>
        ) : (
          <div className="space-y-3">
            {saved!.map((s) => (
              <div key={s.id} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4" data-testid={`card-saved-${s.id}`}>
                {s.destination?.imageUrl && (
                  <img src={s.destination.imageUrl} alt={s.destination.name} className="w-14 h-14 rounded-lg object-cover shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <Link href={`/destinations/${s.destinationId}`} className="font-semibold text-foreground hover:text-primary transition-colors">
                    {s.destination?.name}
                  </Link>
                  <p className="text-muted-foreground text-sm flex items-center gap-1">
                    <MapPin size={11} /> {s.destination?.country}
                  </p>
                </div>
                <button
                  onClick={() => handleUnsave(s.id)}
                  className="text-muted-foreground hover:text-destructive transition-colors"
                  data-testid={`button-unsave-${s.id}`}
                >
                  <X size={16} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
