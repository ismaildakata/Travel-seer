import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Compass, Map, User as UserIcon, Calendar, Plus, Info, LogIn, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useClerk, useUser } from "@clerk/react";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { signOut } = useClerk();
  const { user, isSignedIn } = useUser();

  const navItems = [
    { href: "/", label: "Dashboard", icon: Compass },
    { href: "/destinations", label: "Destinations", icon: Map },
    { href: "/trips", label: "My Trips", icon: Calendar },
    { href: "/profile", label: "Profile", icon: UserIcon },
    { href: "/about", label: "About", icon: Info },
  ];

  const handleSignOut = () => signOut({ redirectUrl: basePath || "/" });

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden">
      <aside className="w-64 border-r border-border bg-card flex flex-col items-stretch p-4 hidden md:flex">
        <div className="flex items-center gap-3 px-2 mb-8 mt-4">
          <div className="w-8 h-8 rounded bg-primary text-primary-foreground flex items-center justify-center">
            <Map size={18} />
          </div>
          <span className="font-serif font-bold text-xl tracking-tight text-foreground">Travel Seer</span>
        </div>

        <nav className="flex-1 space-y-1">
          {navItems.map((item) => {
            const active = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                  active
                    ? "bg-primary/10 text-primary font-medium"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                <item.icon size={18} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="mt-auto space-y-3">
          {isSignedIn ? (
            <>
              <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-accent/50">
                {user?.imageUrl ? (
                  <img src={user.imageUrl} alt={user.fullName ?? ""} className="w-7 h-7 rounded-full object-cover" />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center">
                    <UserIcon size={14} className="text-primary" />
                  </div>
                )}
                <span className="text-sm font-medium text-foreground truncate">{user?.firstName ?? user?.emailAddresses[0]?.emailAddress}</span>
              </div>
              <button
                onClick={handleSignOut}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground hover:text-destructive hover:bg-muted rounded-md transition-colors"
              >
                <LogOut size={16} /> Sign Out
              </button>
            </>
          ) : (
            <div className="space-y-2">
              <Link href="/sign-in" className="block w-full">
                <Button variant="outline" className="w-full gap-2 font-medium">
                  <LogIn size={16} /> Sign In
                </Button>
              </Link>
              <Link href="/sign-up" className="block w-full">
                <Button variant="ghost" className="w-full gap-2 font-medium text-muted-foreground text-sm">
                  Create Account
                </Button>
              </Link>
            </div>
          )}
          <Link href="/trips/new" className="block w-full">
            <Button className="w-full gap-2 shadow-sm font-medium">
              <Plus size={16} /> Plan a Trip
            </Button>
          </Link>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-full overflow-hidden">
        <header className="md:hidden flex items-center justify-between p-4 border-b bg-card">
          <div className="flex items-center gap-2">
            <Map className="text-primary" size={24} />
            <span className="font-serif font-bold text-xl">Travel Seer</span>
          </div>
          <div className="flex items-center gap-2">
            {isSignedIn ? (
              <button onClick={handleSignOut} className="p-2 text-muted-foreground hover:text-destructive rounded-full">
                <LogOut size={18} />
              </button>
            ) : (
              <Link href="/sign-in">
                <Button size="sm" variant="outline" className="gap-1 text-xs">
                  <LogIn size={14} /> Sign In
                </Button>
              </Link>
            )}
            <Link href="/trips/new">
              <Button size="icon" variant="ghost" className="rounded-full">
                <Plus size={20} />
              </Button>
            </Link>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </div>

        <nav className="md:hidden flex items-center justify-around p-3 border-t bg-card pb-safe">
          {navItems.map((item) => {
            const active = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex flex-col items-center gap-1 p-2 ${active ? "text-primary" : "text-muted-foreground"}`}
              >
                <item.icon size={20} />
                <span className="text-[10px]">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </main>
    </div>
  );
}
