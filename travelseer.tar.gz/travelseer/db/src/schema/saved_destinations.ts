import { pgTable, serial, integer, timestamp, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { destinationsTable } from "./destinations";

export const savedDestinationsTable = pgTable(
  "saved_destinations",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
    destinationId: integer("destination_id").notNull().references(() => destinationsTable.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [unique("unique_user_destination").on(table.userId, table.destinationId)]
);

export const insertSavedDestinationSchema = createInsertSchema(savedDestinationsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertSavedDestination = z.infer<typeof insertSavedDestinationSchema>;
export type SavedDestination = typeof savedDestinationsTable.$inferSelect;
