import { Router } from "express";
import { db, destinationsTable } from "@workspace/db";
import { eq, ilike, or } from "drizzle-orm";
import {
  ListDestinationsQueryParams,
  GetDestinationParams,
  CreateDestinationBody,
} from "@workspace/api-zod";

const router = Router();

router.get("/destinations/featured", async (req, res) => {
  try {
    const featured = await db
      .select()
      .from(destinationsTable)
      .where(eq(destinationsTable.isFeatured, true))
      .limit(6);
    res.json(featured.map(formatDestination));
  } catch (err) {
    req.log.error({ err }, "Failed to get featured destinations");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/destinations", async (req, res) => {
  try {
    const parsed = ListDestinationsQueryParams.safeParse(req.query);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid query params" });
    }
    const { search, continent } = parsed.data;

    let query = db.select().from(destinationsTable);

    const conditions = [];
    if (search) {
      conditions.push(
        or(
          ilike(destinationsTable.name, `%${search}%`),
          ilike(destinationsTable.country, `%${search}%`)
        )
      );
    }
    if (continent) {
      conditions.push(eq(destinationsTable.continent, continent));
    }

    const results = conditions.length
      ? await query.where(conditions.length === 1 ? conditions[0] : or(...conditions))
      : await query;

    res.json(results.map(formatDestination));
  } catch (err) {
    req.log.error({ err }, "Failed to list destinations");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/destinations/:id", async (req, res) => {
  try {
    const parsed = GetDestinationParams.safeParse({ id: Number(req.params.id) });
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid id" });
    }
    const [dest] = await db
      .select()
      .from(destinationsTable)
      .where(eq(destinationsTable.id, parsed.data.id));
    if (!dest) return res.status(404).json({ error: "Not found" });
    res.json(formatDestination(dest));
  } catch (err) {
    req.log.error({ err }, "Failed to get destination");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/destinations", async (req, res) => {
  try {
    const parsed = CreateDestinationBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const [dest] = await db
      .insert(destinationsTable)
      .values({
        ...parsed.data,
        avgCostPerDay: String(parsed.data.avgCostPerDay),
      })
      .returning();
    res.status(201).json(formatDestination(dest));
  } catch (err) {
    req.log.error({ err }, "Failed to create destination");
    res.status(500).json({ error: "Internal server error" });
  }
});

function formatDestination(d: typeof destinationsTable.$inferSelect) {
  return {
    ...d,
    avgCostPerDay: parseFloat(String(d.avgCostPerDay)),
    createdAt: d.createdAt.toISOString(),
  };
}

export default router;
