import { Router } from "express";
import { db, savedDestinationsTable, destinationsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  ListSavedDestinationsQueryParams,
  SaveDestinationBody,
  UnsaveDestinationParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/saved-destinations", async (req, res) => {
  try {
    const parsed = ListSavedDestinationsQueryParams.safeParse({
      userId: Number(req.query.userId),
    });
    if (!parsed.success) return res.status(400).json({ error: "Invalid query params" });

    const rows = await db
      .select({ saved: savedDestinationsTable, destination: destinationsTable })
      .from(savedDestinationsTable)
      .leftJoin(destinationsTable, eq(savedDestinationsTable.destinationId, destinationsTable.id))
      .where(eq(savedDestinationsTable.userId, parsed.data.userId));

    res.json(
      rows.map(({ saved, destination }) => ({
        ...saved,
        createdAt: saved.createdAt.toISOString(),
        destination: destination
          ? {
              ...destination,
              avgCostPerDay: parseFloat(String(destination.avgCostPerDay)),
              createdAt: destination.createdAt.toISOString(),
            }
          : undefined,
      }))
    );
  } catch (err) {
    req.log.error({ err }, "Failed to list saved destinations");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/saved-destinations", async (req, res) => {
  try {
    const parsed = SaveDestinationBody.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.message });

    const [saved] = await db
      .insert(savedDestinationsTable)
      .values(parsed.data)
      .onConflictDoNothing()
      .returning();

    if (!saved) {
      const [existing] = await db
        .select()
        .from(savedDestinationsTable)
        .where(
          and(
            eq(savedDestinationsTable.userId, parsed.data.userId),
            eq(savedDestinationsTable.destinationId, parsed.data.destinationId)
          )
        );
      const [destination] = await db
        .select()
        .from(destinationsTable)
        .where(eq(destinationsTable.id, parsed.data.destinationId));
      return res.status(201).json({
        ...existing,
        createdAt: existing.createdAt.toISOString(),
        destination: destination
          ? {
              ...destination,
              avgCostPerDay: parseFloat(String(destination.avgCostPerDay)),
              createdAt: destination.createdAt.toISOString(),
            }
          : undefined,
      });
    }

    const [destination] = await db
      .select()
      .from(destinationsTable)
      .where(eq(destinationsTable.id, saved.destinationId));

    res.status(201).json({
      ...saved,
      createdAt: saved.createdAt.toISOString(),
      destination: destination
        ? {
            ...destination,
            avgCostPerDay: parseFloat(String(destination.avgCostPerDay)),
            createdAt: destination.createdAt.toISOString(),
          }
        : undefined,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to save destination");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/saved-destinations/:id", async (req, res) => {
  try {
    const parsed = UnsaveDestinationParams.safeParse({ id: Number(req.params.id) });
    if (!parsed.success) return res.status(400).json({ error: "Invalid id" });
    await db.delete(savedDestinationsTable).where(eq(savedDestinationsTable.id, parsed.data.id));
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to unsave destination");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
