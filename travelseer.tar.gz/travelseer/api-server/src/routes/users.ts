import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateUserBody,
  GetUserParams,
  UpdateUserParams,
  UpdateUserBody,
} from "@workspace/api-zod";

const router = Router();

router.post("/users", async (req, res) => {
  try {
    const parsed = CreateUserBody.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }
    const [user] = await db.insert(usersTable).values(parsed.data).returning();
    res.status(201).json(formatUser(user));
  } catch (err) {
    req.log.error({ err }, "Failed to create user");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/users/:id", async (req, res) => {
  try {
    const parsed = GetUserParams.safeParse({ id: Number(req.params.id) });
    if (!parsed.success) return res.status(400).json({ error: "Invalid id" });
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, parsed.data.id));
    if (!user) return res.status(404).json({ error: "Not found" });
    res.json(formatUser(user));
  } catch (err) {
    req.log.error({ err }, "Failed to get user");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/users/:id", async (req, res) => {
  try {
    const paramParsed = UpdateUserParams.safeParse({ id: Number(req.params.id) });
    if (!paramParsed.success) return res.status(400).json({ error: "Invalid id" });
    const bodyParsed = UpdateUserBody.safeParse(req.body);
    if (!bodyParsed.success) return res.status(400).json({ error: bodyParsed.error.message });
    const [user] = await db
      .update(usersTable)
      .set(bodyParsed.data)
      .where(eq(usersTable.id, paramParsed.data.id))
      .returning();
    if (!user) return res.status(404).json({ error: "Not found" });
    res.json(formatUser(user));
  } catch (err) {
    req.log.error({ err }, "Failed to update user");
    res.status(500).json({ error: "Internal server error" });
  }
});

function formatUser(u: typeof usersTable.$inferSelect) {
  return {
    ...u,
    createdAt: u.createdAt.toISOString(),
  };
}

export default router;
