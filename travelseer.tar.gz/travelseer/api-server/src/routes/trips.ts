import { Router } from "express";
import { db, tripsTable, destinationsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  ListTripsQueryParams,
  CreateTripBody,
  GetTripParams,
  UpdateTripParams,
  UpdateTripBody,
  DeleteTripParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/trips", async (req, res) => {
  try {
    const parsed = ListTripsQueryParams.safeParse({
      userId: req.query.userId ? Number(req.query.userId) : undefined,
      status: req.query.status,
    });
    if (!parsed.success) return res.status(400).json({ error: "Invalid query params" });

    const { userId, status } = parsed.data;
    const conditions = [];
    if (userId) conditions.push(eq(tripsTable.userId, userId));
    if (status) conditions.push(eq(tripsTable.status, status));

    const trips = await db
      .select({ trip: tripsTable, destination: destinationsTable })
      .from(tripsTable)
      .leftJoin(destinationsTable, eq(tripsTable.destinationId, destinationsTable.id))
      .where(conditions.length ? and(...conditions) : undefined);

    res.json(trips.map(({ trip, destination }) => formatTrip(trip, destination)));
  } catch (err) {
    req.log.error({ err }, "Failed to list trips");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/trips", async (req, res) => {
  try {
    const parsed = CreateTripBody.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.message });

    const [trip] = await db
      .insert(tripsTable)
      .values({
        ...parsed.data,
        budget: parsed.data.budget != null ? String(parsed.data.budget) : null,
      })
      .returning();

    const [destination] = await db
      .select()
      .from(destinationsTable)
      .where(eq(destinationsTable.id, trip.destinationId));

    res.status(201).json(formatTrip(trip, destination ?? null));
  } catch (err) {
    req.log.error({ err }, "Failed to create trip");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/trips/:id", async (req, res) => {
  try {
    const parsed = GetTripParams.safeParse({ id: Number(req.params.id) });
    if (!parsed.success) return res.status(400).json({ error: "Invalid id" });

    const [row] = await db
      .select({ trip: tripsTable, destination: destinationsTable })
      .from(tripsTable)
      .leftJoin(destinationsTable, eq(tripsTable.destinationId, destinationsTable.id))
      .where(eq(tripsTable.id, parsed.data.id));

    if (!row) return res.status(404).json({ error: "Not found" });
    res.json(formatTrip(row.trip, row.destination));
  } catch (err) {
    req.log.error({ err }, "Failed to get trip");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/trips/:id", async (req, res) => {
  try {
    const paramParsed = UpdateTripParams.safeParse({ id: Number(req.params.id) });
    if (!paramParsed.success) return res.status(400).json({ error: "Invalid id" });
    const bodyParsed = UpdateTripBody.safeParse(req.body);
    if (!bodyParsed.success) return res.status(400).json({ error: bodyParsed.error.message });

    const updateData: Record<string, unknown> = { ...bodyParsed.data };
    if (updateData.budget != null) updateData.budget = String(updateData.budget);

    const [trip] = await db
      .update(tripsTable)
      .set(updateData)
      .where(eq(tripsTable.id, paramParsed.data.id))
      .returning();

    if (!trip) return res.status(404).json({ error: "Not found" });

    const [destination] = await db
      .select()
      .from(destinationsTable)
      .where(eq(destinationsTable.id, trip.destinationId));

    res.json(formatTrip(trip, destination ?? null));
  } catch (err) {
    req.log.error({ err }, "Failed to update trip");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/trips/:id", async (req, res) => {
  try {
    const parsed = DeleteTripParams.safeParse({ id: Number(req.params.id) });
    if (!parsed.success) return res.status(400).json({ error: "Invalid id" });
    await db.delete(tripsTable).where(eq(tripsTable.id, parsed.data.id));
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to delete trip");
    res.status(500).json({ error: "Internal server error" });
  }
});

function formatDestination(d: typeof destinationsTable.$inferSelect) {
  return {
    ...d,
    avgCostPerDay: parseFloat(String(d.avgCostPerDay)),
    createdAt: d.createdAt.toISOString(),
  };
}

function formatTrip(
  trip: typeof tripsTable.$inferSelect,
  destination: typeof destinationsTable.$inferSelect | null | undefined
) {
  return {
    ...trip,
    budget: trip.budget != null ? parseFloat(String(trip.budget)) : null,
    createdAt: trip.createdAt.toISOString(),
    destination: destination ? formatDestination(destination) : undefined,
  };
}

export default router;
