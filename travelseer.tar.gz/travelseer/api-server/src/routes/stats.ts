import { Router } from "express";
import { db, tripsTable, destinationsTable, savedDestinationsTable } from "@workspace/db";
import { eq, count, sql } from "drizzle-orm";
import { GetTravelStatsQueryParams } from "@workspace/api-zod";

const router = Router();

router.get("/stats", async (req, res) => {
  try {
    const parsed = GetTravelStatsQueryParams.safeParse({
      userId: req.query.userId ? Number(req.query.userId) : undefined,
    });
    if (!parsed.success) return res.status(400).json({ error: "Invalid query params" });

    const { userId } = parsed.data;

    const [destCount] = await db.select({ count: count() }).from(destinationsTable);

    let tripsQuery = db.select({ count: count(), status: tripsTable.status }).from(tripsTable).groupBy(tripsTable.status);
    const tripsByStatus = userId
      ? await db.select({ count: count(), status: tripsTable.status }).from(tripsTable).where(eq(tripsTable.userId, userId)).groupBy(tripsTable.status)
      : await tripsQuery;

    const totalTrips = tripsByStatus.reduce((s, r) => s + r.count, 0);
    const completedTrips = tripsByStatus.find((r) => r.status === "completed")?.count ?? 0;
    const plannedTrips = tripsByStatus.find((r) => r.status === "planned")?.count ?? 0;

    let countriesVisited = 0;
    let popularContinent: string | null = null;

    if (userId) {
      const visited = await db
        .selectDistinct({ country: destinationsTable.country })
        .from(tripsTable)
        .leftJoin(destinationsTable, eq(tripsTable.destinationId, destinationsTable.id))
        .where(eq(tripsTable.userId, userId));
      countriesVisited = visited.length;

      const continentRows = await db
        .select({ continent: destinationsTable.continent, cnt: count() })
        .from(tripsTable)
        .leftJoin(destinationsTable, eq(tripsTable.destinationId, destinationsTable.id))
        .where(eq(tripsTable.userId, userId))
        .groupBy(destinationsTable.continent)
        .orderBy(sql`count(*) desc`)
        .limit(1);
      popularContinent = continentRows[0]?.continent ?? null;
    } else {
      const continentRows = await db
        .select({ continent: destinationsTable.continent, cnt: count() })
        .from(destinationsTable)
        .groupBy(destinationsTable.continent)
        .orderBy(sql`count(*) desc`)
        .limit(1);
      popularContinent = continentRows[0]?.continent ?? null;
    }

    res.json({
      totalDestinations: destCount.count,
      totalTrips,
      completedTrips,
      plannedTrips,
      totalCountriesVisited: countriesVisited,
      popularContinent,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get travel stats");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
