import { Router, type IRouter } from "express";
import healthRouter from "./health";
import destinationsRouter from "./destinations";
import usersRouter from "./users";
import tripsRouter from "./trips";
import savedDestinationsRouter from "./saved_destinations";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use(destinationsRouter);
router.use(usersRouter);
router.use(tripsRouter);
router.use(savedDestinationsRouter);
router.use(statsRouter);

export default router;
